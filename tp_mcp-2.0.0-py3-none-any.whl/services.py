"""Auto-register Firestore session service for ADK runtime and API server."""
import sys
import os
import logging

logger = logging.getLogger("google_adk.running_coach.services")

# Ensure agents directories are on sys.path
for path in ["/app/agents", "/app/agents/running_coach", "/app", "."]:
    if os.path.exists(path) and path not in sys.path:
        sys.path.insert(0, path)

try:
    from google.adk.cli.service_registry import get_service_registry
    from running_coach.services.session_service import firestore_session_factory
    get_service_registry().register_session_service("firestore", firestore_session_factory)
    logger.info("Successfully registered 'firestore' session service scheme with ADK ServiceRegistry.")
except Exception as e:
    logger.warning(f"Service registry hook initialization: {e}")
