"""TrainingPeaks MCP Server."""

__version__ = "2.3.0"
